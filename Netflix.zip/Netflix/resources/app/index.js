const electron = require('electron');
const app = electron.app;
var path = require('path');
const BrowserWindow = electron.BrowserWindow;
var mainWindow = null;
app.on('ready', function()
    {
        mainWindow= new BrowserWindow(
            {
                fullscreen: true,
                frame: false,
                icon: path.join(__dirname, 'icon/1024x1024.ico')
            });
            mainWindow.loadURL(`https://netflix.com/browse`)
    })
