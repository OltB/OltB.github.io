const electron = require('electron');
const app = electron.app;
const BrowserWindow = electron.BrowserWindow;
var mainWindow = null;
var path = require('path');

app.on('ready' ,function(){
    mainWindow = new BrowserWindow({
            height: 730,
            width: 1360,
            frame: false,
            icon: path.join(__dirname, 'icons/png/64x64.png')
        });
    mainWindow.loadURL(`file://${__dirname}/app/index.html`);
       
})
	